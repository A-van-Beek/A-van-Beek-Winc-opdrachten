## Travel Journal

Part of the Scrimba React course (solo project #2) to practice using props to dynamically update the components :) 

<img src="/images/featureimage.jpg" width= "400">

https://travel-journal.ivavay.repl.co/
